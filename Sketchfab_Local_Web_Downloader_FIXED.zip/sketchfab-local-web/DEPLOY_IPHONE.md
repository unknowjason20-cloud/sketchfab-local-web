# Deploy Sketchfab Local Studio from iPhone

## Important: use a Node.js host, not a static Cloudflare Worker

This application is **not a static-only website**. The browser UI calls backend routes such as `/api/health`, `/api/analyze`, `/api/download`, and `/api/jobs`. Those routes are implemented by `server.js` using Express and Node.js filesystem storage.

If the site is opened on a `*.workers.dev` address and Analyze returns `HTTP 404`, the Worker is serving the frontend without the Express backend. Uploading only `public/` to Cloudflare Pages/Workers will never provide these API routes. Deploy the complete project root to a Node.js web service instead.

## Render deployment (phone-friendly)

1. Download the project ZIP and save it in Files.
2. Create a private GitHub repository named `sketchfab-local-studio`.
3. Upload the ZIP to the repository.
4. Open GitHub Codespaces and create a Codespace for that repository.
5. In its terminal, run (replace the ZIP filename if needed):

```bash
unzip Sketchfab_Full_Web_App_download.zip
cp -a sketchfab-local-web/. .
rm -rf sketchfab-local-web Sketchfab_Full_Web_App_download.zip
```

6. Confirm the repository root contains `package.json`, `server.js`, `render.yaml`, `public/`, and `engine/`.
7. Commit and push the extracted project:

```bash
git add .
git commit -m "Deploy Sketchfab Local Studio backend"
git push
```

8. In Render, choose **New → Blueprint**, connect the repository, and apply the `render.yaml` configuration. If creating a Web Service manually, use:
   - Runtime: **Node**
   - Build command: `npm install`
   - Start command: `npm start`
   - Health check path: `/api/health`
9. Open the `https://...onrender.com` URL. The Developer console should say **Backend connected · Original engine bundle loaded**.
10. Test Analyze with a complete public Sketchfab model URL. The full URL must include the model's 32-character UID suffix.

## Local test

Requires Node.js 20 or later:

```bash
npm install
npm run check
npm start
```

Open `http://localhost:3000`. Verify `http://localhost:3000/api/health` returns JSON with `"ok": true`.

## Free-hosting behavior

Render's free service may sleep when idle and its local filesystem is ephemeral. Download completed ZIPs promptly. Keep Safari in the foreground during model processing. Large models can exceed iPhone memory limits.

The actual Sketchfab download pipeline still needs a live end-to-end test with a public model. The original userscript's page-world/WebGL capture hook is not available automatically from this separate hosted app, so some capture-only textures may be absent.
