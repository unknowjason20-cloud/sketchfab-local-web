# Test Report

Date: 2026-11-13

## Executed checks

| Check | Result | Evidence |
|---|---|---|
| `server.js` JavaScript syntax | PASS | `node --check server.js` |
| `public/app.js` JavaScript syntax | PASS | `node --check public/app.js` |
| `engine/original-engine.js` JavaScript syntax | PASS | `node --check engine/original-engine.js` |
| Embedded WASM binary extraction | PASS | Extracted 253,767-byte WASM payload from the exact supplied source. |
| WASM compile | PASS | `WebAssembly.Module` compiled the original payload; 3 imports and 9 exports were enumerated. |
| WASM instantiate | PASS | Instantiated with the expected `env` import namespace (`abort`, `sbrk`, `memory`). |
| Original ZIP module | PASS | Generated a ZIP using the original `lib/zip.js`; `unzip -t` reported no errors. |
| Browser engine adapter | PASS | Loaded the complete original engine bundle in a VM browser-global harness; adapter exposed the original pipeline and loaded the embedded WASM. |
| Adapter ZIP generation | PASS | Generated a ZIP through the exposed original `buildZip()` API; `unzip -t` reported no errors. |
| Final archive inspection | PASS | `unzip -t Sketchfab_Local_Web_Downloader.zip` reported no errors; archive contains the project directory and all listed source, asset, and documentation files. |

## Not executed / not claimed

- `npm install` did not complete in the build environment (network/package installation timed out); therefore Express was not available for a live server-start/API smoke test here.
- No actual public Sketchfab model was downloaded, so no real-model ZIP/GLB/texture result is claimed.
- No physical iPhone or iOS Safari browser was available; mobile behavior is implemented responsively but not device-tested.
- Bulk queue, SSE behavior, server-side settings restart persistence, and HTTP file delivery have not been exercised against a running Express server.

## Reproduction commands

```bash
npm install
npm run check
npm start
```

Then open `http://localhost:3000`, run the WASM check in Developer console, and test with a public model URL that you are authorized to download. For iPhone testing, open the host computer's LAN IP at port 3000.
