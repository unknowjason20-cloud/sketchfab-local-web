# Feature Audit

## Input inspected

The uploaded file available to the build environment was `Sketchfab_iOS_Full_Downloader.user.js` (659,998 characters), not the ZIP archive named in the request. The original attachment is retained byte-for-byte as `engine/ORIGINAL_SOURCE.user.js`. Its bundled module registry contains:

- `lib/pipeline.js`
- `lib/sf-api.js`
- `lib/decrypt.js`
- `lib/descramble.js`
- `lib/zip.js`
- `lib/osgjs2gltf.js`
- `lib/orm.js`
- `lib/osg-scene.js`
- `lib/osg-codec.js`
- `lib/skin.js`
- `lib/settings.js`

These are preserved in the generated browser engine bundle without replacing their implementation and are also extracted as individual factory-source files under `engine/lib/`. The supplied artifact does not contain separate source files named `ui-settings.js`, `i18n.js`, `save.js`, or `run-download.js`; those names were not fabricated. The uploaded artifact is itself a bundled iOS userscript and includes its UI/controller logic after the module registry.

## Feature status

| Feature | Status | Notes |
|---|---|---|
| Original pipeline | Integrated | Original `downloadModel()` function is exposed to the standalone UI. |
| Original WASM | Preserved | Embedded original base64 payload retained; extracted audit copy is `engine/decrypt.wasm`. |
| WASM compilation/instantiation | Verified in build environment | The exact embedded payload compiles and instantiates with the expected `env` imports. |
| Public model URL parsing | Integrated | Canonical Sketchfab public model URL validation and UID extraction. |
| Public viewer metadata | Integrated | Original pipeline fetches public embed/viewer data through restricted local proxy. |
| `.binz` decryption | Integrated | Original decrypt implementation is called by original pipeline. |
| ZIP writer | Verified independently | Original ZIP module produced a ZIP that passed `unzip -t`. |
| GLB conversion | Integrated, model-dependent | Original osgjs-to-GLB converter is retained and invoked by the pipeline; actual output depends on model data. |
| Texture downloading | Integrated, model-dependent | Public texture endpoint requests use the original texture module. |
| GPU/page-world texture capture | Not ported to standalone origin | The userscript's viewer hook depends on injecting into the Sketchfab page's execution context. A local-origin app cannot transparently inject into the cross-origin Sketchfab viewer, particularly on iOS Safari. Captured-only textures can therefore be absent. |
| Settings persistence | Integrated | Express stores settings in `data/settings.json`. |
| Single job records | Integrated | Job state is held in server memory and streamed over SSE. |
| Bulk queue | Integrated | Sequential processing with per-item status, duplicate filtering, failure tracking, and retry. |
| File delivery | Integrated | Server validates ZIP signature and stores by generated job ID. |
| Floating control panel | Integrated | Open/close state persists in browser local storage; panel scrolls independently. |
| iPhone Safari layout | Designed | Responsive CSS, touch-friendly controls, and safe-area insets are included. No physical iPhone test was performed. |
| Background downloads | Limited by Safari | Browser-side processing requires the tab to remain active; iOS may suspend background tabs. |

## Important architectural choice

The original pipeline runs in the browser, not as a Node worker. This is intentional and preserves its browser-native WebAssembly, fetch, Blob, image, and texture-processing assumptions. Express handles orchestration, persistence, the restricted CORS proxy, progress transport, and file storage. Moving the whole original pipeline into Node would require a separate compatibility port of browser APIs and could silently alter the original engine; that was not done.

## Known technical blockers / limitations

1. The expected ZIP archive was not present among the supplied attachments; only the `.user.js` bundle was available. This audit is based on that actual source.
2. The standalone app cannot reproduce userscript page-world injection into a separate Sketchfab tab. As a result, its GPU/WebGL texture-capture path is not available automatically.
3. Sketchfab may change public embed data, encryption formats, texture endpoints, or CDN hosts. The proxy allowlist intentionally refuses hosts outside `*.sketchfab.com`; new legitimate asset domains would need a reviewed allowlist update.
4. Safari can suspend background tabs and impose memory limits. Large ZIP transfers use base64 JSON between browser and server and can be memory-intensive.
5. The server has no authentication and is intended only for a trusted private LAN. Do not expose it to the public internet.
6. A real download of a selected public model was not run during this build, and physical iPhone Safari compatibility was not empirically verified.
