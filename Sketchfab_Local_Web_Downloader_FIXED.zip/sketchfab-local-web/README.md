# Sketchfab Local Studio

A locally hosted, mobile-first web front end for the original Sketchfab public-model downloader pipeline contained in the supplied source file. The original bundled JavaScript modules and embedded WASM implementation are retained; the pipeline is executed in the browser, while the local Node server provides job records, progress events, settings persistence, a restricted Sketchfab fetch proxy, and ZIP delivery.

> **Source input note:** The attachment available for this build was `Sketchfab_iOS_Full_Downloader.user.js` (about 660 KB), not the `sketchfab-downloader-extension-main.zip` archive named in the build brief. The project was built from the actual attached userscript. Its bundled modules are preserved in `engine/original-engine.js`, and the exact original attachment is retained as `engine/ORIGINAL_SOURCE.user.js`. The WASM payload is also extracted to `engine/decrypt.wasm` for inspection; the original decrypt module continues to use its embedded WASM bytes.

## Requirements

- Node.js 18.18+ (Node 20 LTS recommended; the backend uses the built-in `fetch` API)
- npm
- A device running the Node server and an iPhone on the same trusted Wi-Fi network

## Install and start

```bash
cd sketchfab-local-web
npm install
npm start
```

Open `http://localhost:3000` on the host computer. The server binds to `0.0.0.0`, so it can accept connections from other devices on the LAN.

## Access from iPhone Safari

1. Connect the iPhone and server computer to the same trusted Wi-Fi network.
2. Find the server computer's LAN IPv4 address (for example, `192.168.1.25`).
3. Allow inbound TCP port `3000` in the computer's firewall for the private network only.
4. In iPhone Safari, open `http://192.168.1.25:3000` (replace the example address with the server's actual address).
5. Keep Safari in the foreground while the browser-side model pipeline is running. When complete, tap the generated ZIP link and use Safari's download/share/save flow.

This app does not require a browser extension or userscript manager. The server computer must remain powered on and reachable during processing and file transfer.

## Use

- **Single model:** paste a public Sketchfab model URL, analyze it, then start the download.
- **Bulk queue:** paste one URL per line. Jobs are processed sequentially. Invalid and duplicate model IDs are not submitted. Failed URLs can be retried.
- **Settings:** texture download, original/2K/4K maximum texture edge, full or GLB-focused package, developer logging, theme, and language are persisted in `data/settings.json`.
- **Developer console:** displays pipeline progress and includes a WASM compile/instantiate check.

The engine only accepts canonical public Sketchfab model URLs. It does not access private models, steal credentials, bypass login/paywalls, or attempt DRM circumvention. Only download content you are authorized to use.

## Architecture

- `engine/original-engine.js` contains the original bundled modules and a small adapter exposing the original pipeline API to the standalone UI. Exact module factory source files are also extracted under `engine/lib/` for inspection and maintenance.
- `engine/decrypt.wasm` is the extracted copy of the WASM payload for audit and independent validation. The original decrypt module retains and loads its original embedded payload.
- `public/app.js` invokes the original `downloadModel()` pipeline in the browser. This is deliberate: the supplied pipeline uses browser WebAssembly, Web APIs, and texture processing primitives. Reimplementing those routines in Node would not be a faithful port.
- `server.js` implements Express endpoints, job records, Server-Sent Events, settings persistence, ZIP validation/storage, and a narrowly allowlisted Sketchfab proxy to avoid browser CORS restrictions.
- Generated ZIP files are stored under `data/downloads/` using server-generated IDs. The API does not accept arbitrary output paths.

## API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health and engine status |
| POST | `/api/analyze` | Validate public model URL and extract UID |
| POST | `/api/download` | Create a single download job |
| POST | `/api/bulk` | Create sequential bulk job records |
| GET | `/api/jobs/:id` | Read job status |
| GET | `/api/jobs/:id/events` | SSE progress stream |
| POST | `/api/jobs/:id/status` | Update job status from browser worker |
| POST | `/api/jobs/:id/result` | Validate and store a generated ZIP |
| GET | `/api/downloads/:id` | Download stored ZIP |
| GET/POST | `/api/settings` | Read/write persistent settings |

## Troubleshooting

- **Cannot connect from iPhone:** confirm both devices use the same Wi-Fi, use the server's LAN IP rather than `localhost`, and allow port 3000 through the private-network firewall.
- **Sketchfab request fails:** the app proxies only HTTPS requests to `sketchfab.com` and its subdomains. Network filtering, upstream service changes, rate limits, or changes to Sketchfab's response format can still prevent processing.
- **Model is unsupported:** the retained pipeline currently expects the encrypted `.binz` format and public viewer metadata. It will report a clear error for unsupported/private model formats.
- **Textures are missing:** public texture endpoints may not expose every texture. The original userscript's WebGL/page-world capture hook is not automatically injected into a separate local-origin page, so captured-only texture recovery is not available in this standalone port.
- **Large model stalls or Safari closes:** keep Safari foregrounded, avoid switching apps, and use a device with sufficient memory. iOS may suspend background tabs and has browser-managed memory limits.
- **ZIP link does not save:** tap the link in Safari and use the Downloads list or Share sheet to save it to Files.

## Security and deployment

This is intended for a trusted local network, not public internet exposure. Do not port-forward it. Restrict port 3000 to the private LAN in your firewall. The proxy rejects non-Sketchfab hosts and validates redirect destinations. The server does not provide user authentication; anyone who can reach the port on your LAN can use the app and its local job storage. Keep the host and network trusted.

## Free cloud hosting (iPhone-only access)

A Render Blueprint is included in `render.yaml`. See [`DEPLOY_IPHONE.md`](DEPLOY_IPHONE.md) for the iPhone Safari + GitHub + Render setup. Render's free web service sleeps after 15 minutes idle and has an ephemeral filesystem: settings and generated ZIPs can disappear after sleep, restart, or redeploy. Download completed ZIPs immediately. This is a best-effort free personal setup, not permanent storage or always-on hosting.

The project still needs a real public Sketchfab model download test in iPhone Safari. Do not assume successful end-to-end compatibility until that test passes.
